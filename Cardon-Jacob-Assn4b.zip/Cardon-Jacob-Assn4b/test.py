# Jacob Cardon
# CS1400 - MWF - 8:30am

def main(count:int=100):
    print([(i * 360.0) / count for i in range(count)])

main(6)