# Jacob Cardon
# CS1400 - MWF - 8:30am

print(not(True))